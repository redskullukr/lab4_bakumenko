package stu.cn.ua.lab4_api;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ShipDetailsActivity extends AppCompatActivity {

    private TextView shipIdTextView, shipNameTextView, shipModelTextView, shipActiveTextView;
    private TextView ship_type_detail, ship_weight_lbs_detail, ship_weight_weight_kg_detail, ship_weight_year_built_detail, ship_home_port_detail;
    private ImageView shipImageView;

    JSONPlaceholder jsonPlaceholder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ship_detail);

        shipIdTextView = findViewById(R.id.ship_id_detail);
        shipNameTextView = findViewById(R.id.ship_name_detail);
        shipModelTextView = findViewById(R.id.ship_model_detail);
        shipActiveTextView = findViewById(R.id.ship_active_detail);
        shipImageView = findViewById(R.id.ship_image_detail);
        ship_type_detail = findViewById(R.id.ship_type_detail);
        ship_weight_lbs_detail = findViewById(R.id.ship_weight_lbs_detail);
        ship_weight_weight_kg_detail = findViewById(R.id.ship_weight_weight_kg_detail);
        ship_weight_year_built_detail = findViewById(R.id.ship_weight_year_built_detail);
        ship_home_port_detail = findViewById(R.id.ship_home_port_detail);


        // Инициализация jsonPlaceholder
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.spacexdata.com/v3/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        jsonPlaceholder = retrofit.create(JSONPlaceholder.class);

        // Отримання ship_id з інтенту
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("ship_id")) {
            String shipId = intent.getStringExtra("ship_id");
            getShipDetails(shipId);
        }
    }

    private void getShipDetails(String shipId) {
        // Здійснюємо запит за конкретним ship_id
        Call<Ship> call = jsonPlaceholder.getShipById(shipId);
        call.enqueue(new Callback<Ship>() {
            @Override
            public void onResponse(Call<Ship> call, Response<Ship> response) {
                if (response.isSuccessful()) {
                    Ship ship = response.body();
                    // Відображення деталей корабля в активності
                    shipIdTextView.setText("ID: " + ship.getShip_id());
                    shipNameTextView.setText("Name: " + ship.getShip_name());
                    shipModelTextView.setText("Model: " + ship.getShip_model());
                    shipActiveTextView.setText("Active: " + ship.getActive());
                    ship_type_detail.setText("Type: " + ship.getShip_type());
                    ship_weight_lbs_detail.setText("Weight lbs: " + ship.getWeight_lbs());
                    ship_weight_weight_kg_detail.setText("Weight kg detail: " + ship.getWeight_kg());
                    ship_weight_year_built_detail.setText("Built year: " + ship.getYear_built());
                    ship_home_port_detail.setText("Home port: " + ship.getHome_port());


                    String imageUrl = ship.getImage();

                    if (imageUrl != null) {
                        // Если imageUrl не равно null, используйте Glide для загрузки изображения из сети
                        Glide.with(ShipDetailsActivity.this)
                                .load(imageUrl)
                                .into(shipImageView);
                    } else {
                        // Если imageUrl равно null, используйте изображение из ресурсов
                        Glide.with(ShipDetailsActivity.this)
                                .load(R.drawable.unnamed) // Замените default_image на имя вашего изображения по умолчанию в папке res/drawable
                                .into(shipImageView);
                    }
                } else {
                    // Обробка помилок, якщо вони виникли при запиті
                    Toast.makeText(ShipDetailsActivity.this, "Error: " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Ship> call, Throwable t) {
                // Обробка помилок, якщо вони виникли під час виконання запиту
                Toast.makeText(ShipDetailsActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void onBackButtonClick(View view) {
        onBackPressed();
    }
}
