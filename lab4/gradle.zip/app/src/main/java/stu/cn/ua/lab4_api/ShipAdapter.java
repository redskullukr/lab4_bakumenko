package stu.cn.ua.lab4_api;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.List;

public class ShipAdapter extends RecyclerView.Adapter<ShipAdapter.PostViewHolder> {
    List<Ship> shipList;
    Context context;

    public ShipAdapter(Context context , List<Ship> ships){
        this.context = context;
        shipList = ships;
    }
    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item , parent , false);
        return new PostViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostViewHolder holder, int position) {
        Ship ship = shipList.get(position);
        holder.id.setText("");
        holder.userId.setText(ship.getShip_name());
        holder.title.setText("");

        // Використовуйте Glide для завантаження та відображення зображення із URL
        String imageUrl = ship.getImage();

        if (imageUrl != null) {
            // Если imageUrl не равно null, используйте Glide для загрузки изображения из сети
            Glide.with(holder.itemView.getContext())
                    .load(imageUrl)
                    .into(holder.bodyImage);
        } else {
            // Если imageUrl равно null, используйте изображение из ресурсов
            Glide.with(holder.itemView.getContext())
                    .load(R.drawable.unnamed) // Замените default_image на имя вашего изображения по умолчанию в папке res/drawable
                    .into(holder.bodyImage);
        }

        holder.detailsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Обробка кліку - відкриття нової активності з даними корабля
                Intent intent = new Intent(context, ShipDetailsActivity.class);
                intent.putExtra("ship_id", ship.getShip_id());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return shipList.size();
    }

    public class PostViewHolder extends RecyclerView.ViewHolder{
        TextView title , id , userId;
        ImageView bodyImage;
        Button detailsButton;
        public PostViewHolder(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.title_tv);
            id = itemView.findViewById(R.id.id_tv);
            userId = itemView.findViewById(R.id.user_id_tv);
            bodyImage = itemView.findViewById(R.id.body_image);
            detailsButton = itemView.findViewById(R.id.details_button);

        }
    }
}
