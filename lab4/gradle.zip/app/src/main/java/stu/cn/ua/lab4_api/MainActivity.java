package stu.cn.ua.lab4_api;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.os.Bundle;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    JSONPlaceholder jsonPlaceholder;
    private AppDatabase appDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycerlview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.spacexdata.com/v3/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        jsonPlaceholder = retrofit.create(JSONPlaceholder.class);
        appDatabase = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "ship-database").build();

        getShips();


    }

    public void getShips() {
        Call<List<Ship>> call = jsonPlaceholder.getShips();
        call.enqueue(new Callback<List<Ship>>() {
            @Override
            public void onResponse(Call<List<Ship>> call, Response<List<Ship>> response) {
                if (response.isSuccessful()) {
                    List<Ship> shipList = response.body();

                    // Кешуємо дані в локальній базі даних
                    new Thread(() -> {
                        appDatabase.shipDao().insertShips(shipList);
                    }).start();

                    // Оновлюємо адаптер для відображення даних
                    runOnUiThread(() -> {
                        ShipAdapter shipAdapter = new ShipAdapter(MainActivity.this, shipList);
                        recyclerView.setAdapter(shipAdapter);
                    });
                } else {
                    // Якщо отримання даних не вдалося, відображаємо дані з локальної бази даних
                    new Thread(() -> {
                        List<Ship> localShips = appDatabase.shipDao().getShips();
                        runOnUiThread(() -> {
                            ShipAdapter shipAdapter = new ShipAdapter(MainActivity.this, localShips);
                            recyclerView.setAdapter(shipAdapter);
                        });
                    }).start();
                }
            }

            @Override
            public void onFailure(Call<List<Ship>> call, Throwable t) {
                // Якщо отримання даних не вдалося через помилку, відображаємо дані з локальної бази даних
                new Thread(() -> {
                    List<Ship> localShips = appDatabase.shipDao().getShips();
                    runOnUiThread(() -> {
                        ShipAdapter shipAdapter = new ShipAdapter(MainActivity.this, localShips);
                        recyclerView.setAdapter(shipAdapter);
                    });
                }).start();
            }
        });
    }

}