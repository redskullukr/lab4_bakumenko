package stu.cn.ua.lab4_api;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "ship")
public class Ship {
    @PrimaryKey
    @NonNull
    private String ship_id;
    private String ship_name;
    private String ship_model;
    private String image;
    private String ship_type;

    public Ship() {
    }

    public String getWeight_lbs() {
        return weight_lbs;
    }

    public String getWeight_kg() {
        return weight_kg;
    }

    public String getYear_built() {
        return year_built;
    }

    public String getHome_port() {
        return home_port;
    }

    private String weight_lbs;
    private String weight_kg;
    private String year_built;
    private String home_port;
    public String getShip_type() {
        return ship_type;
    }

    public String getActive() {
        return active;
    }

    private String active;

    public Ship(String ship_id, String ship_name, String ship_model, String image, String shipType, String weightLbs, String weightKg, String yearBuilt, String homePort, String active) {
        this.ship_id = ship_id;
        this.ship_name = ship_name;
        this.ship_model = ship_model;
        this.image = image;
        ship_type = shipType;
        weight_lbs = weightLbs;
        weight_kg = weightKg;
        year_built = yearBuilt;
        home_port = homePort;
        this.active = active;
    }

    public String getShip_id() {
        return ship_id;
    }

    public String getShip_name() {
        return ship_name;
    }

    public String getShip_model() {
        return ship_model;
    }

    public String getImage() {
        return image;
    }

    public void setShip_id(String ship_id) {
        this.ship_id = ship_id;
    }

    public void setShip_name(String ship_name) {
        this.ship_name = ship_name;
    }

    public void setShip_model(String ship_model) {
        this.ship_model = ship_model;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setShip_type(String ship_type) {
        this.ship_type = ship_type;
    }

    public void setWeight_lbs(String weight_lbs) {
        this.weight_lbs = weight_lbs;
    }

    public void setWeight_kg(String weight_kg) {
        this.weight_kg = weight_kg;
    }

    public void setYear_built(String year_built) {
        this.year_built = year_built;
    }

    public void setHome_port(String home_port) {
        this.home_port = home_port;
    }

    public void setActive(String active) {
        this.active = active;
    }
}
