package stu.cn.ua.lab4_api;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

import stu.cn.ua.lab4_api.Ship;

@Dao
public interface ShipDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertShips(List<Ship> ships);

    @Query("SELECT * FROM ship")
    List<Ship> getShips();

    @Query("SELECT * FROM ship WHERE ship_id = :shipId")
    Ship getShipById(String shipId);
}
